<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
<title>Travel blog</title>
<link rel="stylesheet" href="travel.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<nav class="navbar">
  <div class="header">
  <a href="#">Navbar</a>
    <a href="#">Home</a>
    <a href="#">Page 1</a>
    <a href="#">Page 2</a>
    <a href="#">Page 3</a>
  </div>
</nav>
    <div class="container page">
<img src="https://i.pinimg.com/originals/c3/db/69/c3db6909a7b0a25187a911ae7822f1e4.jpg"
 style="width:100%;">
<div class="centered">
 <h1>Come, travel with us...</h1>
 <h2>The real life is outside...</h2>
 <h2>You didn't see the world?! It's time to jump into the advanture...</h2>
 <h2>Don't waste your time, the bigest advanture starts after you left your comfortzone...</h2>
</div>
</div>
<!--The card s start from here-->
<div class="container">
<div class="card-deck">
<div class="card">
  <img src="https://i.pinimg.com/originals/0a/74/41/0a7441d9b3c1613ea3b019b2cfa6d6c3.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">Austria: Green Sea</h5>
    <p class="card-text">Experience a unique natural spectacle.</p>
  </div>
</div>
<div class="card">
  <img src="https://i.pinimg.com/originals/2b/58/4a/2b584aefdbd5acd109870d332e7f3efc.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">Franch: Paris</h5>
    <p class="card-text">‘The city of lights’, ‘the city of Romance’, ‘the culinary capital of the world’, all these are just names Paris, France is known by.</p>
  </div>
</div>
<div class="card">
  <img src="https://i.pinimg.com/originals/48/72/9f/48729f5bd6fddcecc78b71897f486b51.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">U.S.A.: Hawaii and a lot more...</h5>
    <p class="card-text">Discover why the six Islands of Aloha are home to treasures unlike any other on earth: The dramatic cliffs of the Napali Coast on Kauai.</p> 
</div>
</div>
<div class="card">
  <img src="https://lp-cms-production.imgix.net/2019-06/3cb45f6e59190e8213ce0a35394d0e11-nice.jpg?fit=crop&q=40&sharp=10&vib=20&auto=format&ixlib=react-8.6.4" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">French: Nize</h5>
    <p class="card-text">A weekend in Nice doesn’t give you much time to visit the entire French Riviera, but certainly enough to get to know its informal capital, and even the Principality of Monaco.</p>
</div>
</div>
    <div class="card">
  <img src="https://fn-reisen.de/wp-content/uploads/2019/09/Dubai_.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">Arab Emirates: Dubai</h5>
    <p class="card-text">In just a short time, Dubai has become a must-see destination. This Middle Eastern city mixes modernity, luxury, and tradition, and symbolises the new Arab dream.</p>
    </div>
    </div>
    <div class="card">
  <img src="https://c4.wallpaperflare.com/wallpaper/777/871/832/moscow-russia-city-night-kremlin-river-lights-wallpaper-preview.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">Russia: Moscow</h5>
    <p class="card-text">Moscow is a city of contrasts, where the bohemian and the glamorous merge in an idiosyncratic fusion – do not be surprised to find a golden-domed 16th century church next to an ultra-modern glass skyscraper or a Soviet block house.</p>
    </div>
    </div>
    <div class="card">
  <img src="https://www.puzzleexchange.com/wp-content/uploads/Lighting-Venice.jpg" width="500px" class="card-img-top" alt="...">
  <div class="card-body">
  <h5 class="card-title">Italy: Venice</h5>
    <p class="card-text">Engineers love Venice — a completely man-made environment rising from the sea, with no visible means of support.</p>
  </div>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.0.min.js"
integrity="sha256-xNzN2a41tkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ="
crossorigin="anonymous"></script>
<footer><h3>Traveler's Blog</h3></footer>
</body>
</html> 