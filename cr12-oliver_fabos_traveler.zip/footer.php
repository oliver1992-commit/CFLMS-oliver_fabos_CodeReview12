<footer class="footer"><h3>Traveler's Blog</h3>
<?php if(is_active_sidebar('sidebar')) :
dynamic_sidebar('footer-widget');
endif;
?>
</footer>
<?php wp_footer();?>
</body>
</html>