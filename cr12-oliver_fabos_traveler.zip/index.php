<?php get_header(); ?>
<div class="container index">
 <h1>Traveling makes fun</h1>
    <h2>Be ready for the advanture...</h2>
<div class="content">
<?php if(have_posts()) : ?>
    <?php while(have_posts()) : the_post(); ?>
    <?php if(has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('medium-large'); ?>
    <?php endif;?>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
       <p><?php the_time('F j, Y g:i a')?></p>
        <div class="description"><?php the_excerpt(); ?></div>
<?php endwhile; ?>
<?php else :?>
    <?php__('No Posts found'); ?>
<?php endif; ?>
</div>
</div>

<?php get_footer(); ?>
